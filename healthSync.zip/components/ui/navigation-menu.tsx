import { cn } from "@lib/utils";
import { ChevronDown } from "lucide-react";
import { cva } from "class-variance-authority";
import { ComponentPropsWithoutRef, ComponentRef, Ref } from "react";
import * as NavigationMenuPrimitive from "@radix-ui/react-navigation-menu";

const NavigationMenu = ({
  ref,
  className,
  children,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Root> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.Root>>;
}) => (
  <NavigationMenuPrimitive.Root
    ref={ref}
    className={cn("relative z-10 flex items-center justify-center", className)}
    {...props}
  >
    {children}
    <NavigationMenuViewport />
  </NavigationMenuPrimitive.Root>
);
NavigationMenu.displayName = NavigationMenuPrimitive.Root.displayName;

const NavigationMenuList = ({
  ref,
  className,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.List> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.List>>;
}) => (
  <NavigationMenuPrimitive.List
    ref={ref}
    className={cn(
      "group flex flex-1 list-none items-center justify-center gap-1",
      className,
    )}
    {...props}
  />
);
NavigationMenuList.displayName = NavigationMenuPrimitive.List.displayName;

const NavigationMenuItem = NavigationMenuPrimitive.Item;

const navigationMenuTriggerStyle = cva(
  "group inline-flex h-10 w-max items-center justify-center rounded-xl bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-hidden disabled:pointer-events-none disabled:opacity-50 data-active:bg-accent/50 data-[state=open]:bg-accent/50",
);

const NavigationMenuTrigger = ({
  ref,
  className,
  children,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Trigger> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.Trigger>>;
}) => (
  <NavigationMenuPrimitive.Trigger
    ref={ref}
    className={cn(navigationMenuTriggerStyle(), "group", className)}
    {...props}
  >
    {children}{" "}
    <ChevronDown
      className="relative top-px ml-1 h-3 w-3 transition duration-200 group-data-[state=open]:rotate-180"
      aria-hidden="true"
    />
  </NavigationMenuPrimitive.Trigger>
);
NavigationMenuTrigger.displayName = NavigationMenuPrimitive.Trigger.displayName;

const NavigationMenuContent = ({
  ref,
  className,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Content> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.Content>>;
}) => (
  <NavigationMenuPrimitive.Content
    ref={ref}
    className={cn(
      "data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52 data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52 top-0 left-0 w-full md:absolute md:w-auto",
      className,
    )}
    {...props}
  />
);
NavigationMenuContent.displayName = NavigationMenuPrimitive.Content.displayName;

const NavigationMenuLink = NavigationMenuPrimitive.Link;

const NavigationMenuViewport = ({
  ref,
  className,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Viewport> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.Viewport>>;
}) => (
  <div className={cn("absolute top-full left-0 flex justify-center")}>
    <NavigationMenuPrimitive.Viewport
      className={cn(
        "origin-top-center bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90 relative mt-1.5 h-(--radix-navigation-menu-viewport-height) w-full overflow-hidden rounded-xl border shadow-xs md:w-(--radix-navigation-menu-viewport-width)",
        className,
      )}
      ref={ref}
      {...props}
    />
  </div>
);
NavigationMenuViewport.displayName =
  NavigationMenuPrimitive.Viewport.displayName;

const NavigationMenuIndicator = ({
  ref,
  className,
  ...props
}: ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Indicator> & {
  ref?: Ref<ComponentRef<typeof NavigationMenuPrimitive.Indicator>>;
}) => (
  <NavigationMenuPrimitive.Indicator
    ref={ref}
    className={cn(
      "data-[state=visible]:animate-in data-[state=hidden]:animate-out data-[state=hidden]:fade-out data-[state=visible]:fade-in top-full z-1 flex h-1.5 items-end justify-center overflow-hidden",
      className,
    )}
    {...props}
  >
    <div className="bg-border relative top-[60%] h-2 w-2 rotate-45 rounded-tl-sm shadow-xs" />
  </NavigationMenuPrimitive.Indicator>
);
NavigationMenuIndicator.displayName =
  NavigationMenuPrimitive.Indicator.displayName;

export {
  navigationMenuTriggerStyle,
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuContent,
  NavigationMenuTrigger,
  NavigationMenuLink,
  NavigationMenuIndicator,
  NavigationMenuViewport,
};
